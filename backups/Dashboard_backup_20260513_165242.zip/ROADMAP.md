# Dashboard Frontend Roadmap

เป้าหมายของชุดงานนี้คือปรับ `Dashboard` ให้เป็น frontend ที่เหมาะกับการโฮสต์บน GitHub Pages และรับข้อมูลจาก Google Apps Script (GAS) ที่อ่าน/เขียนกับ Google Sheets เป็นหลัก

## เป้าหมายหลัก

1. แยก frontend ออกจาก data layer ให้ชัดเจน
2. ลดการพึ่งพาไฟล์ข้อมูลที่ฝังไว้ใน repository
3. ทำให้ dashboard โหลดข้อมูลจาก API ของ GAS ได้โดยตรง
4. วางโครงสร้าง UI ให้พร้อมขยายในอนาคต
5. รักษาความสามารถเดิมที่จำเป็น เช่น ตาราง, กรอง, เรียง, สรุป KPI, และหน้าเปรียบเทียบรายวัน

## สภาพปัจจุบันที่ต้องเข้าใจ

- `Dashboard/index.html` เป็นหน้า single-page ที่โหลด `app.js`
- `Dashboard/app.js` มีทั้ง logic การแสดงผล, การคำนวณ, การสร้างตาราง, และการจัดการข้อมูล
- ข้อมูลจำนวนมากถูกเก็บแบบ static ใน `data.js`, `fraud_data.js`, `oil-price-data.js`
- มีการใช้ไลบรารีจาก CDN เช่น `flatpickr` และ `xlsx-js-style`
- โครงสร้างหน้าปัจจุบันมีหลายส่วนสำคัญ เช่น:
  - Summary / Master dashboard
  - Daily compare
  - Oil price view

## แนวทางเป้าหมาย

### 1) Frontend ต้องเป็น consumer ของ API

- ย้ายการดึงข้อมูลทั้งหมดไปที่ `fetch()` จาก GAS endpoint
- ให้ frontend ไม่ต้องรู้รายละเอียดการอ่าน Google Sheets โดยตรง
- กำหนดสัญญาข้อมูลกลางเป็น JSON schema ที่ชัดเจน
- รองรับ loading, empty state, และ error state

### 2) Data structure ต้องเป็นเวอร์ชันเดียว

- นิยามรูปแบบ JSON กลางสำหรับทุกหน้า
- แยกข้อมูลออกเป็นหมวด เช่น summary, routeTrend, customerProfit, daily, oilPrice, fraud
- ถ้าข้อมูลยังไม่ครบ ให้ frontend แสดงเฉพาะส่วนที่มีข้อมูลจริง

### 3) UI ต้องโฟกัสที่งานจริง

- ให้ลำดับความสำคัญกับ KPI, trend, ranking, compare, และ drill-down table
- ลดส่วนตกแต่งที่ไม่จำเป็น
- ปรับการอ่านบน desktop เป็นหลัก แต่ต้องใช้ได้บน mobile
- เตรียม UX สำหรับการโหลดข้อมูลช้าและข้อมูลไม่พร้อม

## แผนดำเนินงาน

### Phase 1: Audit และแยกขอบเขต

- ตรวจว่าหน้าใดใช้งานจริงและหน้าใดควรถูกตัดออก
- แยกฟังก์ชันที่เป็น UI, logic, data transformation, และ export
- สรุปข้อมูลที่ต้องได้จาก Sheets สำหรับแต่ละหน้า
- ระบุ field ที่ใช้จริงจาก `app.js`

### Phase 2: สร้าง data contract

- นิยาม JSON response จาก GAS
- ทำตัวอย่าง payload สำหรับแต่ละส่วนของ dashboard
- กำหนดชื่อ field ให้คงที่และอ่านง่าย
- วางกติกาสำหรับ missing/nullable values

### Phase 3: ปรับ frontend architecture

- แยก `app.js` ออกเป็นโมดูลย่อยตามความรับผิดชอบ
- สร้างชั้น `api` สำหรับ fetch และ normalize ข้อมูล
- สร้างชั้น `renderer` สำหรับ render หน้า
- สร้าง utility สำหรับ format ตัวเลข, วันที่, และ label

### Phase 4: ปรับ UI ตามข้อมูลจริง

- ออกแบบ dashboard shell ให้รองรับหลาย section
- ทำ loading skeleton หรือ placeholder
- ทำ error panel ที่บอกปัญหาได้ชัดเจน
- ปรับ responsive layout

### Phase 5: เชื่อม GAS และ Google Sheets

- ทำ GAS endpoint สำหรับอ่านข้อมูล dashboard
- ถ้าจำเป็น ให้ทำ endpoint แยกตามหน้า หรือส่ง payload เดียวที่รวมทุกหน้า
- ตรวจ CORS/การเผยแพร่ script web app ให้ใช้งานจาก GitHub Pages ได้
- วางแนวทาง cache และ refresh

### Phase 6: ตรวจสอบและย้ายขึ้น production

- ทดสอบกับข้อมูลจริงจาก Sheets
- ตรวจ performance ของการ render ตารางขนาดใหญ่
- ตรวจ export flow ถ้ายังต้องใช้
- เตรียม deploy workflow บน GitHub Pages

## สิ่งที่ควรทำก่อนลงมือเขียนโค้ดใหม่

- ลิสต์ว่ามี dataset อะไรบ้างและมาจากแหล่งไหน
- ตรวจว่า `Dashboard/app.js` มีหน้าที่ใดที่ต้องคงไว้
- ตัดสินใจว่า oil price และ fraud data จะมาจาก Sheets เดียวกันหรือคนละ sheet
- เลือกว่าจะใช้ API response แบบรวมทุกอย่าง หรือแยก endpoint ตาม section

## Definition of Done เบื้องต้น

- Dashboard โหลดข้อมูลจาก GAS ได้จริง
- ไม่มี dependency หลักกับ `data.js` แบบ static ใน production
- UI แสดงผลครบตาม section ที่ต้องใช้
- มี state handling สำหรับ loading และ error
- โครงสร้างโค้ดพร้อมขยายต่อ

## หมายเหตุ

เอกสารนี้เป็น roadmap เริ่มต้นสำหรับการรื้อ frontend ใหม่ ถ้าจะเดินต่อจริง ควรเริ่มจากการสรุป data contract ก่อน แล้วค่อย refactor `Dashboard/app.js` ทีละส่วน
